package com.example.billibat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

