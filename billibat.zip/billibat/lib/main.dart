// @dart=2.9
import 'package:flutter/material.dart';
import 'package:nend_plugin/nend_plugin.dart';

import 'bowlard.dart';
import 'cutoff.dart';

//メイン
void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key key}) : super(key: key);

  @override
  MyAppState createState() => MyAppState();
}

BannerAdController adController;
//int spotId = 1053203;
//String apiKey = "725b2b5af4d2670c81e4d9551f746ae81497a3ad";

//テスト用
int spotId = 3174;
String apiKey = "c5cb8bc474345961c6e7a9778c947957ed8e1e4f";

/*
class MyAppState extends State<MyApp> {
  @override
  void initState() {
    super.initState();
  }

  final _menu = [
    'Banner',
//    'Setting Ad Logger',
  ];

  final _samples = [
    BannerSample(),
//    SettingAdLogger(),
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('nend plugin example'),
        ),
        body: ListView.builder(
          itemCount: _menu.length,
          itemBuilder: (context, index) {
            return Column(
              children: [
                ListTile(
                  contentPadding: EdgeInsets.symmetric(horizontal: 8),
                  title: Text(
                    _menu[index],
                    textAlign: TextAlign.left,
                  ),
                  onTap: () {
                    Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) => _samples[index],
                    ));
                  },
                ),
                Divider(height: 0),
              ],
            );
          },
        ),
      ),
    );
  }
}
*/
/*
class StateDisplay extends StatelessWidget {
  StateDisplay({this.title, this.state, this.color});
  final String? state;
  final String? title;
  final Color? color;
  @override
  Widget build(BuildContext context) {
    return Text(
      '$title state: $state',
      key: Key(title!),
      style: TextStyle(color: color),
    );
  }
}
*/

class MyAppState extends State<MyApp> {
  BannerAdController adController;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(primarySwatch: Colors.blue),
      home: Scaffold(
        body: Column(children: [
          SizedBox(height: 100),
          Text("テスト"),
          Container(
            decoration: const BoxDecoration(
              border: Border(right: BorderSide(width: 1), top: BorderSide(width: 1), bottom: BorderSide(width: 1)),
            ),
            child: BannerAd(
              bannerSize: BannerSize.type320x50,
              listener: _eventListener(),
              onCreated: (controller) {
                adController = controller;
                adController.load(spotId: spotId, apiKey: apiKey);
              },
            ),
          ),
        ]),
      ),
    );
  }

  BannerAdListener _eventListener() {
    return BannerAdListener(
      onLoaded: () => print('onLoaded'),
      onReceiveAd: () => print('onReceived'),
      onFailedToLoad: () => print('onFailedToLoad'),
      onAdClicked: () => print('onAdClicked'),
      onInformationClicked: () => print('onInformationClicked'),
    );
  }

/*
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(primarySwatch: Colors.blue),
      home: Scaffold(
        appBar: const Header(),
        body: Stack(
          alignment: Alignment.center,
          children: const [
            Image(image: AssetImage('images/top2.jpg'), fit: BoxFit.cover),
            Positioned(
              top: 20.0,
              width: 300.0,
              height: 50.0,
              child: Button01(),
            ),
            Positioned(
              top: 90.0,
              width: 300.0,
              height: 50.0,
              child: Button02(),
            ),
/*
広告
            Positioned(
              bottom: 0.0,
              child: Koukoku(),
            ),
 */
            BannerAd(
              bannerSize: BannerSize.type320x50,
              listener: _eventListener(),
              onCreated: (controller) {
                adController = controller;
                adController.load(spotId: spotId, apiKey: apiKey);
              },
            ),
          ],
          fit: StackFit.expand,
        ),
      ),
    );
  }
 */

}

//ボーラードボタン
class Button01 extends StatelessWidget {
  const Button01({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      child: const Text('ボーラード', style: TextStyle(fontSize: 24)),
      style: ElevatedButton.styleFrom(
        primary: Colors.grey[200],
        onPrimary: Colors.black,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
      onPressed: () {
        Navigator.of(context).push(MaterialPageRoute(builder: (context) {
          return const Bowlard();
        }));
      },
    );
  }
}

//3球取り切りボタン
class Button02 extends StatelessWidget {
  const Button02({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      child: const Text('cutoff', style: TextStyle(fontSize: 24)),
      style: ElevatedButton.styleFrom(
        primary: Colors.grey[200],
        onPrimary: Colors.black,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
      onPressed: () {
        Navigator.of(context).push(MaterialPageRoute(builder: (context) {
          return const CutOff();
        }));
      },
    );
  }
}
